﻿/*
 * Creado por SharpDevelop.
 * Usuario: makir
 * Fecha: 11/12/2025
 * Hora: 02:06 p. m.
 * 
 * Para cambiar esta plantilla use Herramientas | Opciones | Codificación | Editar Encabezados Estándar
 */
namespace boleta
{
	partial class c1
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.c2 = new System.Windows.Forms.TextBox();
			this.c3 = new System.Windows.Forms.TextBox();
			this.c4 = new System.Windows.Forms.TextBox();
			this.c5 = new System.Windows.Forms.TextBox();
			this.c6 = new System.Windows.Forms.TextBox();
			this.c7 = new System.Windows.Forms.TextBox();
			this.txtPromedio = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.LavenderBlush;
			this.label1.Location = new System.Drawing.Point(21, 38);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(197, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Formacion Socioemocional lll";
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.LavenderBlush;
			this.label2.Location = new System.Drawing.Point(21, 85);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(120, 23);
			this.label2.TabIndex = 1;
			this.label2.Text = "Humanidades lll";
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.LavenderBlush;
			this.label3.Location = new System.Drawing.Point(21, 131);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 23);
			this.label3.TabIndex = 2;
			this.label3.Text = "Inglés lll";
			// 
			// label4
			// 
			this.label4.BackColor = System.Drawing.Color.LavenderBlush;
			this.label4.Location = new System.Drawing.Point(21, 178);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(206, 23);
			this.label4.TabIndex = 3;
			this.label4.Text = "Lengua y comunicacion lll";
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.LavenderBlush;
			this.label5.Location = new System.Drawing.Point(21, 224);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(181, 23);
			this.label5.TabIndex = 5;
			this.label5.Text = "Pensamiento matemático lll";
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.LavenderBlush;
			this.label6.Location = new System.Drawing.Point(21, 270);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(133, 23);
			this.label6.TabIndex = 6;
			this.label6.Text = "Metodologías ágiles ";
			// 
			// label7
			// 
			this.label7.BackColor = System.Drawing.Color.LavenderBlush;
			this.label7.Location = new System.Drawing.Point(21, 317);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(147, 23);
			this.label7.TabIndex = 7;
			this.label7.Text = "Empleas frameworks";
			// 
			// label8
			// 
			this.label8.BackColor = System.Drawing.Color.LavenderBlush;
			this.label8.Location = new System.Drawing.Point(28, 359);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(113, 23);
			this.label8.TabIndex = 8;
			this.label8.Text = "Calificación final:";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(224, 35);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(100, 22);
			this.textBox1.TabIndex = 9;
			// 
			// c2
			// 
			this.c2.Location = new System.Drawing.Point(160, 87);
			this.c2.Name = "c2";
			this.c2.Size = new System.Drawing.Size(100, 22);
			this.c2.TabIndex = 10;
			// 
			// c3
			// 
			this.c3.Location = new System.Drawing.Point(127, 132);
			this.c3.Name = "c3";
			this.c3.Size = new System.Drawing.Size(100, 22);
			this.c3.TabIndex = 11;
			// 
			// c4
			// 
			this.c4.Location = new System.Drawing.Point(233, 178);
			this.c4.Name = "c4";
			this.c4.Size = new System.Drawing.Size(100, 22);
			this.c4.TabIndex = 12;
			// 
			// c5
			// 
			this.c5.Location = new System.Drawing.Point(215, 225);
			this.c5.Name = "c5";
			this.c5.Size = new System.Drawing.Size(100, 22);
			this.c5.TabIndex = 13;
			// 
			// c6
			// 
			this.c6.Location = new System.Drawing.Point(160, 271);
			this.c6.Name = "c6";
			this.c6.Size = new System.Drawing.Size(100, 22);
			this.c6.TabIndex = 14;
			// 
			// c7
			// 
			this.c7.Location = new System.Drawing.Point(174, 317);
			this.c7.Name = "c7";
			this.c7.Size = new System.Drawing.Size(100, 22);
			this.c7.TabIndex = 15;
			// 
			// txtPromedio
			// 
			this.txtPromedio.Location = new System.Drawing.Point(160, 359);
			this.txtPromedio.Name = "txtPromedio";
			this.txtPromedio.Size = new System.Drawing.Size(100, 22);
			this.txtPromedio.TabIndex = 16;
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.Location = new System.Drawing.Point(99, 406);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(143, 48);
			this.button1.TabIndex = 17;
			this.button1.Text = "Calcular";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// c1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.AliceBlue;
			this.ClientSize = new System.Drawing.Size(355, 482);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.txtPromedio);
			this.Controls.Add(this.c7);
			this.Controls.Add(this.c6);
			this.Controls.Add(this.c5);
			this.Controls.Add(this.c4);
			this.Controls.Add(this.c3);
			this.Controls.Add(this.c2);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Name = "c1";
			this.Text = "boleta";
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox txtPromedio;
		private System.Windows.Forms.TextBox c7;
		private System.Windows.Forms.TextBox c6;
		private System.Windows.Forms.TextBox c5;
		private System.Windows.Forms.TextBox c4;
		private System.Windows.Forms.TextBox c3;
		private System.Windows.Forms.TextBox c2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
	}
}
